package com.huobi.service.huobi.utils;

public class HuobiHttpInvoker {



}
