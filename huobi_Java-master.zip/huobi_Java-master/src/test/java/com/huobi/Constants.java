package com.huobi;

public class Constants {

  public static final String API_KEY = "api key";
  public static final String SECRET_KEY = "secret key";
}
