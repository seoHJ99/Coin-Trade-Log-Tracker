package com.huobi.constant;

public class WebSocketConstants {

  public static final String OP_SUB = "sub";
  public static final String OP_REQ = "req";

  public static final String ACTION_SUB = "sub";
  public static final String ACTION_REP = "rep";


}
