package com.huobi.constant.enums;

public enum  EtfSwapDirectionEnum {

  SWAP_IN_ETF,
  SWAP_OUT_ETF
  ;

}
