package com.huobi.constant;

public class Constants {

  public static final String API_KEY = "AccessKey";
  public static final String SECRET_KEY = "SecretKey";

}
