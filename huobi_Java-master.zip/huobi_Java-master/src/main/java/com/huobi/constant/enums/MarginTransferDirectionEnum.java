package com.huobi.constant.enums;

public enum  MarginTransferDirectionEnum {

  SPOT_TO_MARGIN,
  MARGIN_TO_SPOT
  ;
}
