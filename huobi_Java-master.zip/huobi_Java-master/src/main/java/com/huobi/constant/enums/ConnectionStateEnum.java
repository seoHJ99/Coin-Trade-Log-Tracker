package com.huobi.constant.enums;

public enum ConnectionStateEnum {
  IDLE,
  DELAY_CONNECT,
  CONNECTED,
  CLOSED_ON_ERROR
}
